## HOW TO COMPILE


To compile HW3, run this command:

```gcc --std=gnu99 -o smallsh smallsh.c```

## HOW TO RUN THE PROGRAM

To run the program, run this command:

```./smallsh```

To test this program, run this command:

```./p3testscript 2>&1```