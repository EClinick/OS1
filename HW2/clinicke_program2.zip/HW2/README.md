## HOW TO COMPILE


To compile HW1, run this command:

```gcc --std=gnu99 -o movies_by_year movies_by_year.c```

## HOW TO RUN THE PROGRAM

To run the program, run this command:

```./movies```

