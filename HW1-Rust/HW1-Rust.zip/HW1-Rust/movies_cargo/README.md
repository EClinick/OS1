## HOW TO COMPILE AND RUN

To compile the Rust program, run this command in the project directory:

```cargo run ./movies_sample_1.csv```

## Directory Structure

The Rust programs are in /movies_cargo in /HW1-Rust

/HW1-Rust/movies_cargo/..


