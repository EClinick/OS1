## HOW TO COMPILE


To compile HW1, run this command:

```gcc --std=gnu99 -o movies movies.c```

## HOW TO RUN THE PROGRAM

To run the program, run this command:

```./movies <CSV WITH MOVIE DATA>```

i.e.

```./movies movies_sample_1.csv```