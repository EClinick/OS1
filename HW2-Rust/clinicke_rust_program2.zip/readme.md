## HOW TO COMPILE AND RUN

To compile the Rust program, run this command in the project directory:

```cargo run ```

## Directory Structure

The Rust programs are in /files_and_directories in /HW2-Rust

/HW2-Rust/files_and_directories/..


